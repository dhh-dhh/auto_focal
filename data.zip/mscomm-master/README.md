# mscomm
vs2015 Develop serial tools using mscomm activex
